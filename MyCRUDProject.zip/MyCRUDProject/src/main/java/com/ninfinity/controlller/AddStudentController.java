package com.ninfinity.controlller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ninfinity.dao.DatabaseConnect;
import com.ninfinity.dao.StudentDAO;
import com.ninfinity.entities.Student;

/**
 * Servlet implementation class AddStudentController
 */
@WebServlet("/AddStudentController")
public class AddStudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String city = request.getParameter("city");
		String email = request.getParameter("email");
		
		
		Student s1 = new Student(firstName, lastName, city, email);
		
		StudentDAO sdao = new StudentDAO(DatabaseConnect.connect());
		boolean status = sdao.addOneStudent(s1);
		
		HttpSession session = request.getSession();
		
		
		
		if(status) {
			session.setAttribute("success", "Student Added Successfully");
			response.sendRedirect("AddStudent.jsp");
			
		}else {
			System.out.println("problem in Addition");
		}
		
		//PrintWriter out = response.getWriter();
		//response.setContentType("text/html");
		//out.print("<h1> zala student add </h1>");
		
		
		
		
		
	}

}
