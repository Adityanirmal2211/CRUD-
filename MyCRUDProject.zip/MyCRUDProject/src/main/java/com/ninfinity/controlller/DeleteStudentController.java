package com.ninfinity.controlller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ninfinity.dao.DatabaseConnect;
import com.ninfinity.dao.StudentDAO;

/**
 * Servlet implementation class DeleteStudentController
 */
@WebServlet("/DeleteStudentController")
public class DeleteStudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		int id = Integer.parseInt(request.getParameter("id"));
		
		StudentDAO sDao = new StudentDAO(DatabaseConnect.connect());
		
		boolean status = sDao.deleteStudentById(id);
		
		if(status) {
			response.sendRedirect("DisplayStudent.jsp");
		}
		
		
		
		
	}

}
