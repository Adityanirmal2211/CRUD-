package com.ninfinity.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ninfinity.entities.Student;

public class StudentDAO {

	Connection con;
	
	public StudentDAO(Connection con) {
		this.con = con;
	}
	
	public boolean addOneStudent(Student s1) {
		
		boolean status = true;
		String query = "insert into studenttable (firstName, lastName, city, email) values (?,?,?,?)";
		
		  try {
			PreparedStatement pstmt= con.prepareStatement(query);
			pstmt.setString(1, s1.getFirstName());
			pstmt.setString(2, s1.getLastName());
			pstmt.setString(3, s1.getCity());
			pstmt.setString(4, s1.getEmail());
			
			int n = pstmt.executeUpdate();
			if(n==1) {
				status= true;
			}else {
				status = false;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
		return status;
		
		
		
	}
	
	
	
	
	public ArrayList<Student>getAllStudents(){
		ArrayList<Student> studentList= new ArrayList<Student>();
		
		
		
		
		
		 String query="select * from studenttable ";
		 
		try {
			PreparedStatement pstmt=con.prepareStatement(query);
			
			
			ResultSet result=pstmt.executeQuery();
			while(result.next()) {
				
				Student s1=new Student();
				
				s1.setId(result.getInt(1));
				s1.setFirstName(result.getString(2));
				s1.setLastName(result.getString(3));
				s1.setCity(result.getString(4));
				s1.setEmail(result.getString(5));
				
				
				studentList.add(s1);
			}
			
			con.close();
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return studentList;
		
	}
	
	
	public Student getStudentById(int id) {
		
		Student s1=new Student();
		
		String query="select * from studenttable where id=?";
		try {
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1,id);
			ResultSet result= pstmt.executeQuery();
			
			while(result.next()) {
				s1.setId(result.getInt(1));
				s1.setFirstName(result.getString(2));
				s1.setLastName(result.getString(3));
				s1.setCity(result.getString(4));
				s1.setEmail(result.getString(5));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s1;
	}
	
	
	
	public boolean UpdateOneStudent(Student s1) {
		boolean status =  true;
		PreparedStatement pstmt;
		String querry= "update studenttable set firstName=?, lastName =? , city=?  , email=?  where id =?";
		try {
			pstmt = con.prepareStatement(querry);
			pstmt.setString(1, s1.getFirstName());
			pstmt.setString(2, s1.getLastName());
			pstmt.setString(3, s1.getCity());
			pstmt.setString(4, s1.getEmail());
			pstmt.setInt(5, s1.getId());
			
			int n = pstmt.executeUpdate();
			
			con.close();
			
			if(n == 1) {
				status = true;
			}else {
				status = false;
			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		return status;

	}
	
	public boolean 
	deleteStudentById(int id) {
		
		boolean status = false;
		
		String query = "delete from studenttable where id =?";
		
		
		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			
			pstmt.setInt(1, id);
			
			int n = pstmt.executeUpdate();
			
            if (n==1) {
            	status = true;
            }
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
}
