package com.ninfinity.helper;

import com.ninfinity.dao.DatabaseConnect;

public class Test {
	
	public static void main(String[] args) {
		
		DatabaseConnect.connect();
		
	}
	
	

}
